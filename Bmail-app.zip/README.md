# About

Basic GAE project with Jinja templating engine

# Usage

1. Click on Download ZIP
2. Save on your disk and unzip
4. Build something nice ;)
5. Run the app with this command: `dev_appserver.py ./`
6. Open your browser and go to: `http://localhost:8080`

